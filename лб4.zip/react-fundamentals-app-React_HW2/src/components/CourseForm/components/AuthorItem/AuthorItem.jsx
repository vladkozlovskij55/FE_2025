import React from "react";
import styles from "./styles.module.css";

export const AuthorItem = ({ name, onClick, buttonText, dataTestId }) => (
  <div className={styles.authorItem} data-testid="authorItem">
    <span>{name}</span>
    <button type="button" onClick={() => onClick(name)}>
      {buttonText}
    </button>
  </div>
);
