// Module 1. You don't need to do anything with this component (we had to comment this component for 1st module tests)

// Module 2.
// * uncomment this component (ctrl + a => ctrl + /)
// * finish markup according to the figma https://www.figma.com/design/m0N0SGLclqUEGR6TUNvyn9/Fundamentals-Courses?node-id=2932-219&t=OXbHXwMixWTtxRSw-1
// * add validation for fields: all fields are required. Show validation message. https://www.figma.com/design/m0N0SGLclqUEGR6TUNvyn9/Fundamentals-Courses?node-id=2932-257&t=OXbHXwMixWTtxRSw-1
// * render this component by route '/registration'
// * submit form data and make POST API request '/registration'.
// * after successful registration navigates to '/login' route.
// * component should have a link to the Login page (see design)
// ** TASK DESCRIPTION ** - https://react-fundamentals-tasks.vercel.app/docs/module-2/home-task/components#registration-new-component

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Input } from "../../common/Input";
import { Button } from "../../common/Button";
import { createUser } from "../../services";
import styles from "./styles.module.css";

export const Registration = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const validateForm = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = "Name is required";
    if (!form.email.trim()) newErrors.email = "Email is required";
    if (!form.password.trim()) newErrors.password = "Password is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      const result = await createUser({
        name: form.name,
        email: form.email,
        password: form.password,
      });
      console.log("Registration success:", result);
      navigate("/login");
    } catch (error) {
      console.error("Registration failed:", error.message);
      alert("Registration failed");
    }
  };

  return (
    <div className={styles.container}>
      <h1>Registration</h1>
      <div className={styles.formContainer}>
        <form onSubmit={handleSubmit}>
          <Input
            name="email"
            labelText="Email"
            placeholderText="Enter your email"
            value={form.email}
            onChange={handleChange}
            data-testid="email"
          />
          {errors.email && <p className={styles.error}>{errors.email}</p>}

          <Input
            name="name"
            labelText="Name"
            placeholderText="Enter your name"
            value={form.name}
            onChange={handleChange}
            data-testid="name"
          />
          {errors.name && <p className={styles.error}>{errors.name}</p>}

          <Input
            name="password"
            type="password"
            labelText="Password"
            placeholderText="Enter your password"
            value={form.password}
            onChange={handleChange}
            data-testid="password"
          />
          {errors.password && <p className={styles.error}>{errors.password}</p>}

          <Button
            type="submit"
            buttonText="Register"
            data-testid="registerButton"
          />
        </form>
        <p>
          If you have an account you may&nbsp;
          <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
};
