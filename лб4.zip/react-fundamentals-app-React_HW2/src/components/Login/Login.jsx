// Module 1. You don't need to do anything with this component (we had to comment this component for 1st module tests)

// Module 2.
// * uncomment this component (ctrl + a => ctrl + /)
// * finish markup according to the figma https://www.figma.com/design/m0N0SGLclqUEGR6TUNvyn9/Fundamentals-Courses?node-id=2927-216&t=OXbHXwMixWTtxRSw-1
// * add validation for fields: all fields are required. Show validation message. https://www.figma.com/design/m0N0SGLclqUEGR6TUNvyn9/Fundamentals-Courses?node-id=2932-191&t=OXbHXwMixWTtxRSw-1
// * render this component by route '/login'
// * use login service to submit form data and make POST API request '/login'.
// * component should have a link to the Registration page (see design)
// * save token from API after success login to localStorage.
// ** PAY ATTENTION ** token should be saved to localStorage inside login handler function after login service response
// ** TASK DESCRIPTION ** - https://react-fundamentals-tasks.vercel.app/docs/module-2/home-task/components#login-new-component

// Module 3.
// * use 'setUserData' from 'userSlice.js' to save user's name, token and email to the store after success login.
// ** TASK DESCRIPTION ** - https://react-fundamentals-tasks.vercel.app/docs/module-3/home-task/components#login-component

// Module 4.
// * use 'setUserData' from 'userSlice.js' to add user's data to store. (DO NOT use 'user/me' [GET] request)

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Input } from "../../common/Input";
import { Button } from "../../common//Button";
import { login } from "../../services";
import styles from "./styles.module.css";

export const Login = () => {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!form.email.trim()) newErrors.email = "Email is required";
    if (!form.password.trim()) newErrors.password = "Password is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    try {
      const result = await login(form);
      localStorage.setItem("token", result.result);
      navigate("/courses");
    } catch (error) {
      setErrors({ api: error.message });
    }
  };

  return (
    <div className={styles.container}>
      <h1>Login</h1>
      <div className={styles.formContainer}>
        <form onSubmit={handleSubmit}>
          <Input
            type="email"
            name="email"
            labelText="Email"
            value={form.email}
            onChange={handleChange}
            placeholder="Enter your email"
            data-testid="email"
          />
          {errors.email && <p className={styles.error}>{errors.email}</p>}

          <Input
            type="password"
            name="password"
            labelText="Password"
            value={form.password}
            onChange={handleChange}
            placeholder="Enter your password"
            data-testid="password"
          />
          {errors.password && <p className={styles.error}>{errors.password}</p>}

          <Button buttonText="Login" type="submit" />
          {errors.api && <p className={styles.error}>{errors.api}</p>}
        </form>
        <p>
          If you don't have an account you may&nbsp;
          <Link to="/registration">Registration</Link>
        </p>
      </div>
    </div>
  );
};
