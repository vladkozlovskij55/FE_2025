import React from "react";
import { Button } from "../../common/Button/Button";

export const EmptyCourseList = () => (
  <div data-testid="emptyContainer">
    <h2>Your List Is Empty</h2>
    <p>Please use "Add New Course" button to add your first course</p>
    <Button
      buttonText="ADD NEW COURSE"
      handleClick={() => {}}
      data-testid="addCourse"
    />
  </div>
);
