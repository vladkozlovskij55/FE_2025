import React from "react";
import { Input } from "../../common/Input/Input";
import { Button } from "../../common/Button/Button";
import styles from "./styles.module.css";

export const SearchBar = ({ searchTerm, setSearchTerm, onSearch }) => {
  const handleSearch = () => {
    onSearch();
  };

  return (
    <div className={styles.searchBar}>
      <label htmlFor="search" className={styles.label}></label>
      <Input
        id="search"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Enter course title or ID"
      />
      <Button
        buttonText="SEARCH"
        handleClick={handleSearch}
        data-testid="searchButton"
      />
    </div>
  );
};
