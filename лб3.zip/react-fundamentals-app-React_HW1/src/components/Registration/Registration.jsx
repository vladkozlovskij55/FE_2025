// // Module 1. You don't need to do anything with this component (we had to comment this component for 1st module tests)
//
// // Module 2.
// // * uncomment this component (ctrl + a => ctrl + /)
// // * finish markup according to the figma https://www.figma.com/design/m0N0SGLclqUEGR6TUNvyn9/Fundamentals-Courses?node-id=2932-219&t=OXbHXwMixWTtxRSw-1
// // * add validation for fields: all fields are required. Show validation message. https://www.figma.com/design/m0N0SGLclqUEGR6TUNvyn9/Fundamentals-Courses?node-id=2932-257&t=OXbHXwMixWTtxRSw-1
// // * render this component by route '/registration'
// // * submit form data and make POST API request '/registration'.
// // * after successful registration navigates to '/login' route.
// // * component should have a link to the Login page (see design)
// // ** TASK DESCRIPTION ** - https://react-fundamentals-tasks.vercel.app/docs/module-2/home-task/components#registration-new-component
//
// import React from "react";

// import styles from "./styles.module.css";

// export const Registration = () => {
//   // write your code here

//   return (
//     <div className={styles.container}>
//       <h1>Registration</h1>
//       <div className={styles.formContainer}>
//         <form onSubmit={handleSubmit}>
//           // reuse Input component for email field
//           // reuse Input component for name field
//           // reuse Input component for password field
//           // reuse Button component for 'Login' button
//         </form>
//         <p>
//           If you have an account you may&nbsp; // use <Link /> component for navigation to Login page
//         </p>
//       </div>
//     </div>
//   );
// };
