import { getCourseDuration } from "./getCourseDuration";
import { formatCreationDate } from "./formatCreationDate";

export { getCourseDuration, formatCreationDate };
