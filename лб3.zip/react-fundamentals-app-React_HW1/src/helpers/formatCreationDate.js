export const formatCreationDate = (date) => {
  if (!date) return "";

  let dateStr =
    typeof date === "string" ? date : date.toLocaleDateString("en-US");

  const parts = dateStr.split("/");
  if (parts.length !== 3) return "";

  const [day, month, year] = parts;

  return `${day.padStart(2, "0")}.${month.padStart(2, "0")}.${year}`;
};
